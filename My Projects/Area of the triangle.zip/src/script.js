// Header sentence
console.log("The area of the triangle is: ")

// variables that hold the triangles sides
let side1 = 5;
let side2 = 6;
let side3 = 7;
let s,area,round;
// Calculating the area of the triangle using Heron's Formula
s = (side1 + side2 + side3)/2;
area = Math.sqrt(s*(s-side1)*(s-side2)*(s-side3))
round = area.toFixed(1)
console.log(round)


